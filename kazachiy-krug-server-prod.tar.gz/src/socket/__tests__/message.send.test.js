import test from "node:test";
import assert from "node:assert/strict";

import { messageSocket } from "../message.socket.js";
import { prisma } from "../../db/prisma.js";

let originalUserBlockFindFirst;
test.beforeEach(() => {
    originalUserBlockFindFirst = prisma.userBlock.findFirst;
    prisma.userBlock.findFirst = async () => null;
});
test.afterEach(() => { prisma.userBlock.findFirst = originalUserBlockFindFirst; });

function createFakeSocket(userId = "user-1", role = "user") {
    return {
        data: {
            isAuth: true,
            userId,
            userName: "Test User",
            user: {
                id: userId,
                role,
            },
        },
        handlers: new Map(),
        emitted: [],
        on(event, handler) {
            this.handlers.set(event, handler);
        },
        emit(event, payload) {
            this.emitted.push({ event, payload });
        },
    };
}

function createFakeIo() {
    return {
        to() {
            return {
                emit() {},
            };
        },
    };
}

test("message:send rejects readonly group publish when user not in publishUserIds", async () => {
    const socket = createFakeSocket("user-1");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalGroupRuleFindUnique = prisma.groupRule.findUnique;
    const originalMessageCreate = prisma.message.create;

    let createCalled = false;

    prisma.chat.findFirst = async () => ({
        id: "group-1",
        type: "group",
        members: [{ userId: "user-1" }, { userId: "user-2" }],
    });
    prisma.groupRule.findUnique = async () => ({
        mode: "readonly",
        requiresAnnouncementWithImage: false,
        publishUserIds: ["user-2"],
    });
    prisma.message.create = async () => {
        createCalled = true;
        throw new Error("should not create");
    };

    try {
        const handler = socket.handlers.get("message:send");
        assert.ok(handler, "message:send handler should be registered");

        await handler({ id: "m-1", chatId: "group-1", text: "hello" });

        const errorEvent = socket.emitted.find((item) => item.event === "message:error");
        assert.ok(errorEvent, "message:error should be emitted");
        assert.equal(errorEvent.payload.reason, "У вас нет прав на публикацию в этой группе.");
        assert.equal(createCalled, false, "prisma.message.create must not be called");
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.groupRule.findUnique = originalGroupRuleFindUnique;
        prisma.message.create = originalMessageCreate;
    }
});

test("message:send allows a moderator to publish in the public information group", async () => {
    const socket = createFakeSocket("moderator-1", "moderator");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalGroupRuleFindUnique = prisma.groupRule.findUnique;
    const originalMessageCreate = prisma.message.create;

    let createCalled = false;

    prisma.chat.findFirst = async () => ({
        id: "group-1",
        type: "group",
        members: [],
    });
    prisma.groupRule.findUnique = async () => ({
        mode: "readonly",
        visibility: "public",
        publishPolicy: "admin_moderator",
        status: "active",
        requiresAnnouncementWithImage: false,
        publishUserIds: ["user-1"],
        publishers: [],
    });
    prisma.message.create = async () => {
        createCalled = true;
        return {
            id: "m-info",
            chatId: "group-1",
            senderId: "moderator-1",
            text: "important information",
            type: "text",
            imageUrl: null,
            imageUrls: null,
            attachments: [],
            status: "sent",
            createdAt: new Date(),
        };
    };

    try {
        await socket.handlers.get("message:send")({
            id: "m-info",
            chatId: "group-1",
            text: "important information",
        });

        assert.equal(createCalled, true);
        assert.equal(socket.emitted.some((item) => item.event === "message:error"), false);
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.groupRule.findUnique = originalGroupRuleFindUnique;
        prisma.message.create = originalMessageCreate;
    }
});

test("message:send does not let an administrator bypass selected authors", async () => {
    const socket = createFakeSocket("admin-1", "admin");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalGroupRuleFindUnique = prisma.groupRule.findUnique;
    const originalMessageCreate = prisma.message.create;

    let createCalled = false;

    prisma.chat.findFirst = async () => ({
        id: "group-2",
        type: "group",
        members: [],
    });
    prisma.groupRule.findUnique = async () => ({
        mode: "readonly",
        visibility: "public",
        publishPolicy: "selected_authors",
        status: "active",
        requiresAnnouncementWithImage: false,
        publishUserIds: [],
        publishers: [{ userId: "author-1" }],
    });
    prisma.message.create = async () => {
        createCalled = true;
        throw new Error("should not create");
    };

    try {
        await socket.handlers.get("message:send")({
            id: "m-selected",
            chatId: "group-2",
            text: "not assigned",
        });

        const errorEvent = socket.emitted.find((item) => item.event === "message:error");
        assert.equal(errorEvent?.payload.reason, "У вас нет прав на публикацию в этой группе.");
        assert.equal(createCalled, false);
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.groupRule.findUnique = originalGroupRuleFindUnique;
        prisma.message.create = originalMessageCreate;
    }
});

test("message:send keeps private group hidden even from a non-member administrator", async () => {
    const socket = createFakeSocket("admin-1", "admin");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalGroupRuleFindUnique = prisma.groupRule.findUnique;
    const originalMessageCreate = prisma.message.create;

    let createCalled = false;

    prisma.chat.findFirst = async () => ({
        id: "group-13",
        type: "group",
        members: [{ userId: "user-7" }],
    });
    prisma.groupRule.findUnique = async () => ({
        mode: "chat",
        visibility: "private",
        publishPolicy: "members",
        status: "active",
        requiresAnnouncementWithImage: false,
        publishUserIds: [],
        publishers: [],
    });
    prisma.message.create = async () => {
        createCalled = true;
        throw new Error("should not create");
    };

    try {
        await socket.handlers.get("message:send")({
            id: "m-private",
            chatId: "group-13",
            text: "no access",
        });

        const errorEvent = socket.emitted.find((item) => item.event === "message:error");
        assert.equal(errorEvent?.payload.reason, "У вас нет доступа к этой группе.");
        assert.equal(createCalled, false);
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.groupRule.findUnique = originalGroupRuleFindUnique;
        prisma.message.create = originalMessageCreate;
    }
});

test("message:send allows an active user to publish in a public category without chat membership", async () => {
    const socket = createFakeSocket("user-9", "user");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalGroupRuleFindUnique = prisma.groupRule.findUnique;
    const originalMessageCreate = prisma.message.create;

    let createCalled = false;

    prisma.chat.findFirst = async () => ({
        id: "group-4",
        type: "group",
        members: [{ userId: "user-1" }],
    });
    prisma.groupRule.findUnique = async () => ({
        mode: "announcements",
        visibility: "public",
        publishPolicy: "members",
        status: "active",
        requiresAnnouncementWithImage: false,
        publishUserIds: [],
        publishers: [],
    });
    prisma.message.create = async () => {
        createCalled = true;
        return {
            id: "m-public",
            chatId: "group-4",
            senderId: "user-9",
            text: "public category",
            type: "text",
            imageUrl: null,
            imageUrls: null,
            attachments: [],
            status: "sent",
            createdAt: new Date(),
        };
    };

    try {
        await socket.handlers.get("message:send")({
            id: "m-public",
            chatId: "group-4",
            text: "public category",
        });

        assert.equal(createCalled, true);
        assert.equal(socket.emitted.some((item) => item.event === "message:error"), false);
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.groupRule.findUnique = originalGroupRuleFindUnique;
        prisma.message.create = originalMessageCreate;
    }
});

test("message:send rejects announcements without image when required", async () => {
    const socket = createFakeSocket("user-1");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalGroupRuleFindUnique = prisma.groupRule.findUnique;
    const originalMessageCreate = prisma.message.create;

    let createCalled = false;

    prisma.chat.findFirst = async () => ({
        id: "group-4",
        type: "group",
        members: [{ userId: "user-1" }, { userId: "user-2" }],
    });
    prisma.groupRule.findUnique = async () => ({
        mode: "announcements",
        requiresAnnouncementWithImage: true,
        publishUserIds: null,
    });
    prisma.message.create = async () => {
        createCalled = true;
        throw new Error("should not create");
    };

    try {
        const handler = socket.handlers.get("message:send");
        assert.ok(handler, "message:send handler should be registered");

        await handler({ id: "m-2", chatId: "group-4", text: "announcement without image" });

        const errorEvent = socket.emitted.find((item) => item.event === "message:error");
        assert.ok(errorEvent, "message:error should be emitted");
        assert.equal(
            errorEvent.payload.reason,
            "Для групп 4–10 требуется формат: объявление + картинка (text + image attachment)."
        );
        assert.equal(createCalled, false, "prisma.message.create must not be called");
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.groupRule.findUnique = originalGroupRuleFindUnique;
        prisma.message.create = originalMessageCreate;
    }
});

test("message:send allows announcement with image attachment and text", async () => {
    const socket = createFakeSocket("user-1");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalGroupRuleFindUnique = prisma.groupRule.findUnique;
    const originalMessageCreate = prisma.message.create;

    let createCalled = false;

    prisma.chat.findFirst = async () => ({
        id: "group-4",
        type: "group",
        members: [{ userId: "user-1" }, { userId: "user-2" }],
    });
    prisma.groupRule.findUnique = async () => ({
        mode: "announcements",
        requiresAnnouncementWithImage: true,
        publishUserIds: null,
    });
    prisma.message.create = async () => {
        createCalled = true;
        return {
            id: "m-2a",
            chatId: "group-4",
            senderId: "user-1",
            text: "announcement with attachment",
            type: "media",
            imageUrl: null,
            imageUrls: null,
            attachments: [{ id: "a-2a", mediaType: "image", url: "/uploads/pic.png" }],
            status: "sent",
            createdAt: new Date(),
        };
    };

    try {
        const handler = socket.handlers.get("message:send");
        assert.ok(handler, "message:send handler should be registered");

        await handler({
            id: "m-2a",
            chatId: "group-4",
            text: "announcement with attachment",
            attachments: [{ mediaType: "image", url: "/uploads/pic.png" }],
        });

        assert.equal(createCalled, true, "prisma.message.create must be called for valid attachment-based announcement");
        const errorEvent = socket.emitted.find((item) => item.event === "message:error");
        assert.equal(errorEvent, undefined, "message:error should not be emitted");
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.groupRule.findUnique = originalGroupRuleFindUnique;
        prisma.message.create = originalMessageCreate;
    }
});



test("message:send canonicalizes legacy imageUrl payload into image attachment", async () => {
    const socket = createFakeSocket("user-1");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalGroupRuleFindUnique = prisma.groupRule.findUnique;
    const originalMessageCreate = prisma.message.create;

    let createPayload = null;

    prisma.chat.findFirst = async () => ({
        id: "group-1",
        type: "group",
        members: [{ userId: "user-1" }, { userId: "user-2" }],
    });
    prisma.groupRule.findUnique = async () => ({
        mode: "chat",
        requiresAnnouncementWithImage: false,
        publishUserIds: null,
    });
    prisma.message.create = async (payload) => {
        createPayload = payload;
        return {
            id: "m-img-1",
            chatId: "group-1",
            senderId: "user-1",
            text: payload.data.text,
            type: payload.data.type,
            imageUrl: payload.data.imageUrl,
            imageUrls: payload.data.imageUrls,
            attachments: payload.data.attachments.create.map((attachment, idx) => ({
                id: `img-a-${idx + 1}`,
                ...attachment,
            })),
            status: "sent",
            createdAt: new Date(),
        };
    };

    try {
        const handler = socket.handlers.get("message:send");
        assert.ok(handler, "message:send handler should be registered");

        await handler({
            id: "m-img-1",
            chatId: "group-1",
            text: "photo",
            imageUrl: "/uploads/photo.png",
        });

        assert.ok(createPayload, "prisma.message.create should be called");
        assert.equal(createPayload.data.type, "media");
        assert.equal(createPayload.data.imageUrl, null);
        assert.equal(createPayload.data.imageUrls, null);
        assert.equal(createPayload.data.attachments.create.length, 1);
        assert.equal(createPayload.data.attachments.create[0].mediaType, "image");
        assert.equal(createPayload.data.attachments.create[0].url, "/uploads/photo.png");

        const newEvent = socket.emitted.find((item) => item.event === "message:new");
        assert.ok(newEvent, "message:new should be emitted");
        assert.equal(newEvent.payload.type, "media");
        assert.equal(newEvent.payload.imageUrl, null);
        assert.equal(newEvent.payload.attachments[0].mediaType, "image");
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.groupRule.findUnique = originalGroupRuleFindUnique;
        prisma.message.create = originalMessageCreate;
    }
});


test("message:send normalizes invalid message type and attachment media type", async () => {
    const socket = createFakeSocket("user-1");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalGroupRuleFindUnique = prisma.groupRule.findUnique;
    const originalMessageCreate = prisma.message.create;

    let createPayload = null;

    prisma.chat.findFirst = async () => ({
        id: "group-1",
        type: "group",
        members: [{ userId: "user-1" }, { userId: "user-2" }],
    });
    prisma.groupRule.findUnique = async () => ({
        mode: "chat",
        requiresAnnouncementWithImage: false,
        publishUserIds: null,
    });
    prisma.message.create = async (payload) => {
        createPayload = payload;

        return {
            id: "m-3",
            chatId: "group-1",
            senderId: "user-1",
            text: "voice",
            type: payload.data.type,
            imageUrl: null,
            imageUrls: null,
            attachments: [
                {
                    id: "a-1",
                    mediaType: payload.data.attachments.create[0].mediaType,
                    url: payload.data.attachments.create[0].url,
                    mimeType: payload.data.attachments.create[0].mimeType,
                    sizeBytes: payload.data.attachments.create[0].sizeBytes,
                    durationMs: payload.data.attachments.create[0].durationMs,
                    waveform: payload.data.attachments.create[0].waveform,
                    width: null,
                    height: null,
                },
            ],
            status: "sent",
            createdAt: new Date(),
        };
    };

    try {
        const handler = socket.handlers.get("message:send");
        assert.ok(handler, "message:send handler should be registered");

        await handler({
            id: "m-3",
            chatId: "group-1",
            text: "voice",
            type: "VOICE_NOTE",
            attachments: [
                {
                    mediaType: "AUDIO_NOTE",
                    url: "  /uploads/v1.ogg  ",
                    mimeType: "audio/ogg",
                    sizeBytes: 1234,
                    durationMs: 5400,
                },
            ],
        });

        assert.ok(createPayload, "prisma.message.create should be called");
        assert.equal(createPayload.data.type, "media");
        assert.equal(createPayload.data.attachments.create.length, 1);
        assert.equal(createPayload.data.attachments.create[0].mediaType, "file");
        assert.equal(createPayload.data.attachments.create[0].url, "/uploads/v1.ogg");

        const newEvent = socket.emitted.find((item) => item.event === "message:new");
        assert.ok(newEvent, "message:new should be emitted");
        assert.equal(newEvent.payload.type, "media");
        assert.equal(newEvent.payload.attachments[0].mediaType, "file");
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.groupRule.findUnique = originalGroupRuleFindUnique;
        prisma.message.create = originalMessageCreate;
    }
});

test("message:send keeps allowed media message type and audio attachment", async () => {
    const socket = createFakeSocket("user-1");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalGroupRuleFindUnique = prisma.groupRule.findUnique;
    const originalMessageCreate = prisma.message.create;

    let createPayload = null;

    prisma.chat.findFirst = async () => ({
        id: "group-1",
        type: "group",
        members: [{ userId: "user-1" }, { userId: "user-2" }],
    });
    prisma.groupRule.findUnique = async () => ({
        mode: "chat",
        requiresAnnouncementWithImage: false,
        publishUserIds: null,
    });
    prisma.message.create = async (payload) => {
        createPayload = payload;

        return {
            id: "m-4",
            chatId: "group-1",
            senderId: "user-1",
            text: "",
            type: payload.data.type,
            imageUrl: null,
            imageUrls: null,
            attachments: payload.data.attachments.create.map((attachment, idx) => ({
                id: `a-${idx + 1}`,
                ...attachment,
            })),
            status: "sent",
            createdAt: new Date(),
        };
    };

    try {
        const handler = socket.handlers.get("message:send");
        assert.ok(handler, "message:send handler should be registered");

        await handler({
            id: "m-4",
            chatId: "group-1",
            text: "",
            type: "media",
            attachments: [
                {
                    mediaType: "audio",
                    url: "/uploads/v2.ogg",
                    mimeType: "audio/ogg",
                    sizeBytes: 2000,
                    durationMs: 1000,
                },
            ],
        });

        assert.ok(createPayload, "prisma.message.create should be called");
        assert.equal(createPayload.data.type, "media");
        assert.equal(createPayload.data.attachments.create[0].mediaType, "audio");

        const newEvent = socket.emitted.find((item) => item.event === "message:new");
        assert.ok(newEvent, "message:new should be emitted");
        assert.equal(newEvent.payload.type, "media");
        assert.equal(newEvent.payload.attachments[0].mediaType, "audio");
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.groupRule.findUnique = originalGroupRuleFindUnique;
        prisma.message.create = originalMessageCreate;
    }
});

test("message:send canonicalizes voice payload to media with empty text", async () => {
    const socket = createFakeSocket("user-1");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalGroupRuleFindUnique = prisma.groupRule.findUnique;
    const originalMessageCreate = prisma.message.create;

    let createPayload = null;

    prisma.chat.findFirst = async () => ({
        id: "group-1",
        type: "group",
        members: [{ userId: "user-1" }, { userId: "user-2" }],
    });
    prisma.groupRule.findUnique = async () => ({
        mode: "chat",
        requiresAnnouncementWithImage: false,
        publishUserIds: null,
    });
    prisma.message.create = async (payload) => {
        createPayload = payload;

        return {
            id: "m-voice",
            chatId: "group-1",
            senderId: "user-1",
            text: payload.data.text,
            type: payload.data.type,
            imageUrl: null,
            imageUrls: null,
            attachments: payload.data.attachments.create.map((attachment, idx) => ({
                id: `a-voice-${idx + 1}`,
                ...attachment,
            })),
            status: "sent",
            createdAt: new Date(),
        };
    };

    try {
        const handler = socket.handlers.get("message:send");
        assert.ok(handler, "message:send handler should be registered");

        await handler({
            id: "m-voice",
            chatId: "group-1",
            text: "voice note",
            type: "text",
            attachments: [
                {
                    mediaType: "audio",
                    url: "/uploads/voice.ogg",
                    mimeType: "audio/ogg",
                    durationMs: 3200,
                },
            ],
        });

        assert.ok(createPayload, "prisma.message.create should be called");
        assert.equal(createPayload.data.type, "media");
        assert.equal(createPayload.data.text, "");
        assert.equal(createPayload.data.attachments.create[0].mediaType, "audio");

        const newEvent = socket.emitted.find((item) => item.event === "message:new");
        assert.ok(newEvent, "message:new should be emitted");
        assert.equal(newEvent.payload.type, "media");
        assert.equal(newEvent.payload.text, "");
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.groupRule.findUnique = originalGroupRuleFindUnique;
        prisma.message.create = originalMessageCreate;
    }
});

test("message:send allows publish when publishUserIds is empty array and mode=chat", async () => {
    const socket = createFakeSocket("user-1");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalGroupRuleFindUnique = prisma.groupRule.findUnique;
    const originalMessageCreate = prisma.message.create;

    let createCalled = false;

    prisma.chat.findFirst = async () => ({
        id: "group-2",
        type: "group",
        members: [{ userId: "user-1" }, { userId: "user-2" }],
    });
    prisma.groupRule.findUnique = async () => ({
        mode: "chat",
        requiresAnnouncementWithImage: false,
        publishUserIds: [],
    });
    prisma.message.create = async () => {
        createCalled = true;
        return {
            id: "m-5",
            chatId: "group-2",
            senderId: "user-1",
            text: "allowed",
            type: "text",
            imageUrl: null,
            imageUrls: null,
            attachments: [],
            status: "sent",
            createdAt: new Date(),
        };
    };

    try {
        const handler = socket.handlers.get("message:send");
        assert.ok(handler, "message:send handler should be registered");

        await handler({ id: "m-5", chatId: "group-2", text: "allowed" });

        assert.equal(createCalled, true, "message should be created when publishUserIds is [] and mode=chat");
        const errorEvent = socket.emitted.find((item) => item.event === "message:error");
        assert.equal(errorEvent, undefined, "message:error should not be emitted");
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.groupRule.findUnique = originalGroupRuleFindUnique;
        prisma.message.create = originalMessageCreate;
    }
});

test("message:send falls back to legacy message schema when media fields are unavailable", async () => {
    const socket = createFakeSocket("user-1");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalMessageCreate = prisma.message.create;

    const createPayloads = [];

    prisma.chat.findFirst = async () => ({
        id: "room-user-1-user-4",
        type: "private",
        members: [{ userId: "user-1" }, { userId: "user-4" }],
    });
    prisma.message.create = async (payload) => {
        createPayloads.push(payload);

        if (payload.data.type) {
            throw new Error("Unknown argument `type`. Did you mean `text`?");
        }

        return {
            id: payload.data.id,
            chatId: payload.data.chatId,
            senderId: payload.data.senderId,
            text: payload.data.text,
            imageUrl: payload.data.imageUrl,
            imageUrls: payload.data.imageUrls,
            status: "sent",
            createdAt: new Date("2026-05-11T12:00:00.000Z"),
        };
    };

    try {
        const handler = socket.handlers.get("message:send");
        assert.ok(handler, "message:send handler should be registered");

        await handler({
            id: "m-legacy",
            chatId: "room-user-1-user-4",
            text: "ппппп",
            type: "text",
        });

        assert.equal(createPayloads.length, 2, "message create should be retried without media fields");
        assert.equal(createPayloads[0].data.type, "text");
        assert.equal(createPayloads[1].data.type, undefined);
        assert.equal(createPayloads[1].data.attachments, undefined);

        const newEvent = socket.emitted.find((item) => item.event === "message:new");
        assert.ok(newEvent, "message:new should be emitted after legacy create fallback");
        assert.equal(newEvent.payload.id, "m-legacy");
        assert.equal(newEvent.payload.type, "text");

        const deliveredEvent = socket.emitted.find((item) => item.event === "message:delivered");
        assert.ok(deliveredEvent, "message:delivered should be emitted after legacy create fallback");
        assert.equal(deliveredEvent.payload.messageId, "m-legacy");
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.message.create = originalMessageCreate;
    }
});

test("message:send persists voice URL in legacy message schema", async () => {
    const socket = createFakeSocket("user-1");
    messageSocket(createFakeIo(), socket);

    const originalChatFindFirst = prisma.chat.findFirst;
    const originalMessageCreate = prisma.message.create;

    const createPayloads = [];

    prisma.chat.findFirst = async () => ({
        id: "room-user-1-user-4",
        type: "private",
        members: [{ userId: "user-1" }, { userId: "user-4" }],
    });
    prisma.message.create = async (payload) => {
        createPayloads.push(payload);

        if (payload.data.attachments) {
            throw new Error("Unknown argument `attachments`.");
        }

        return {
            id: payload.data.id,
            chatId: payload.data.chatId,
            senderId: payload.data.senderId,
            text: payload.data.text,
            imageUrl: payload.data.imageUrl,
            imageUrls: payload.data.imageUrls,
            status: "sent",
            createdAt: new Date("2026-05-11T12:00:00.000Z"),
        };
    };

    try {
        const handler = socket.handlers.get("message:send");
        assert.ok(handler, "message:send handler should be registered");

        await handler({
            id: "m-legacy-voice",
            chatId: "room-user-1-user-4",
            text: "",
            type: "media",
            attachments: [
                {
                    mediaType: "audio",
                    url: "http://localhost:3000/uploads/voice.webm",
                    mimeType: "audio/webm",
                    durationMs: 1200,
                },
            ],
        });

        assert.equal(createPayloads.length, 2, "message create should retry legacy schema");
        assert.equal(createPayloads[1].data.imageUrl, "http://localhost:3000/uploads/voice.webm");

        const newEvent = socket.emitted.find((item) => item.event === "message:new");
        assert.ok(newEvent, "message:new should be emitted after legacy voice fallback");
        assert.equal(newEvent.payload.attachments[0].mediaType, "audio");
        assert.equal(newEvent.payload.attachments[0].url, "http://localhost:3000/uploads/voice.webm");
    } finally {
        prisma.chat.findFirst = originalChatFindFirst;
        prisma.message.create = originalMessageCreate;
    }
});
