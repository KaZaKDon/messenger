// chatId → объект чата
export const chats = {
    "room-1": {
        id: "room-1",
        members: ["user-1", "user-2"],
        messages: [],
    },
};
